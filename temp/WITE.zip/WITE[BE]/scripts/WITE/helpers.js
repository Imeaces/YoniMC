import * as Minecraft from 'Minecraft';
import { Entidad } from "scripts/WITE/entidad.js";
export const addCaracter = (string,caracterToAdd,every) => {
	let finalString = ``;
	const stringLength = string.length;
	for(let i = 0; i<stringLength;i+= every){
		if(i + every < stringLength){
			finalString += string.substring(i,i+every) + caracterToAdd;
		}else{
			finalString += string.substring(i,stringLength);
		}
	}
	return finalString;
}
export function etiqueta(target){
	const faces = [ "juan", "up", "down", "north", "south", "west", "east" ];
	for(var i in faces){
		try{
			Minecraft.Commands.run(`tag @a[name="${target}"] remove ${faces[i]}`, Minecraft.World.getDimension("overworld"))
		} catch(error){}
	}
}
export class ENTIDAD{
	static from(dimension){
	var jugadores = Minecraft.World.getPlayers();
	for(var i in jugadores){
		var pX = Math.floor(jugadores[i].location.x);
		var pY = Math.floor(jugadores[i].location.y);
		var pZ = Math.floor(jugadores[i].location.z);
		var entitiesAtNorth = Minecraft.World.getDimension(`${dimension}`).getEntitiesAtBlockLocation(new Minecraft.BlockLocation(pX, pY-1, pZ-2));
	   var entitiesAtSouth= Minecraft.World.getDimension(`${dimension}`).getEntitiesAtBlockLocation(new Minecraft.BlockLocation(pX, pY-1, pZ+2));
	   var entitiesAtEast = Minecraft.World.getDimension(`${dimension}`).getEntitiesAtBlockLocation(new Minecraft.BlockLocation(pX+2, pY-1, pZ));
		var entitiesAtWest = Minecraft.World.getDimension(`${dimension}`).getEntitiesAtBlockLocation(new Minecraft.BlockLocation(pX-2, pY-1, pZ));
		if(entitiesAtNorth.length > 0){
		  var entidad1 = new Entidad(entitiesAtNorth[0],jugadores[i].name,"north");
		  entidad1.queryNombre();
		  entidad1.queryNameTag();
		  entidad1.queryVida();
		  entidad1.queryContainer();
		  entidad1.displayIcon();
		  entidad1.showDatos();
	   }if(entitiesAtSouth.length > 0){
		 var entidad2 = new Entidad(entitiesAtSouth[0],jugadores[i].name,"south");
		entidad2.queryNombre();
		entidad2.queryVida();
		entidad2.queryNameTag();
		entidad2.queryContainer();
		entidad2.displayIcon();
		entidad2.showDatos();
	   }if(entitiesAtEast.length > 0){
		var entidad3 = new Entidad(entitiesAtEast[0],jugadores[i].name,"east");
		entidad3.queryNombre();
		entidad3.queryVida();
		entidad3.queryNameTag();
		entidad3.queryContainer();
		entidad3.displayIcon();
		entidad3.showDatos();
	   }
	   if(entitiesAtWest.length > 0){
		var entidad4 = new Entidad(entitiesAtWest[0],jugadores[i].name,"west");
		entidad4.queryNombre();
		entidad4.queryNameTag();
		entidad4.queryVida();
		entidad4.queryContainer();
		entidad4.displayIcon();
		entidad4.showDatos();
	   }
	}
}
}