import * as Minecraft from 'Minecraft';
import { BlockLocation } from "Minecraft";
import { ENTIDAD, etiqueta } from "scripts/WITE/helpers.js";

Minecraft.World.events.beforeChat.subscribe(EventData => {
	var cmd = EventData.message.split(' ');
	if(cmd[0] == "+show"){
	  try{
		  Minecraft.Commands.run(`tag @a[name=${EventData.sender.name}] add juan`, Minecraft.World.getDimension("overworld"));
	  }catch(error){error = `juan.tag.error`; Minecraft.Commands.run(`tellraw @a[name="${EventData.sender.name}"] {"rawtext": [ { "translate": "${error}" } ]}`, Minecraft.World.getDimension("overworld")) }
	  EventData.cancel = true;
	}else if(cmd[0] == "+hide"){
		etiqueta(EventData.sender.name);
		EventData.cancel = true;
	}
});

Minecraft.World.events.tick.subscribe(() => {
	try{
		var nombres = Minecraft.Commands.run(`testfor @a[tag="juan"]`, Minecraft.World.getDimension("overworld")).victim;
		for(var yo in nombres){
			Minecraft.Commands.run(`execute @a[name="${nombres[yo]}"] ~~~ summon add:etiqueta ~~~`, Minecraft.World.getDimension("overworld"));
		}
	}catch(error){}
	ENTIDAD.from("overworld");
	ENTIDAD.from("nether");
	ENTIDAD.from("the end");
});