import * as Minecraft from 'Minecraft';
import { addCaracter } from "scripts/WITE/helpers.js";

export class Entidad {
	constructor(entity,target,tag){
		this.entity = entity,
		this.target = target,
		this.tag = tag,
		this.pet = undefined,
		this.age = undefined,
		this.animal = undefined,
		this.NameTag = undefined,
		this.Nombre = undefined,
		this.color = undefined,
		this.from = undefined,
		this.Vida = undefined,
		this.Container = this.entity.getComponent("minecraft:inventory")
	}
	queryNameTag(){
		if(this.entity.getComponent("minecraft:color") !== undefined){
			this.color = `{"text": "\n§r"}, {"translate": "juan.entity.color"}, {"text": " §9${this.entity.getComponent("minecraft:color").value}"},`;
	    }else{this.color = `{"text": ""},`;}
		if(this.entity.nameTag !== undefined && (this.entity.nameTag != "")){
			if(this.entity.nameTag.length > 12){
				this.NameTag = `{"text": "\n§r"}, {"translate": "juan.entity.name"}, {"text": " §9${addCaracter(this.entity.nameTag,"-\n",12)}"},`;
			}else{
			this.NameTag = `{"text": "\n§r"}, {"translate": "juan.entity.name"}, {"text": " §9${this.entity.nameTag}"},`;}
		}else{
			this.NameTag = `{"text": ""},`;
		}
		if(this.entity.getComponent("minecraft:tamemount") !== undefined){
			this.animal = `{"text": "\n§r"},{"translate": "juan.animal.wild"},`;
		}else{this.animal = `{"text": ""},`;}
		if(this.entity.getComponent("minecraft:ageable") !== undefined){
			var ageItems = this.entity.getComponent("minecraft:ageable").feedItems[0].item;
			if(ageItems !== undefined){if(ageItems.startsWith("minecraft")){ageItems = `item.${ageItems.substring(10)}.name`}else{ageItems = `item.${ageItems}.name`}}else{ageItems = "None"};
			this.age = `{"text": "\n§r"},{"translate": "juan.animal.baby"},{"text": "\n"},{"translate": "juan.animal.feed"},{"text": "[§9"},{"translate": "${ageItems}"},{"text": "§r]"},`;
		}else{this.age = `{"text": ""},`;}
	}
	queryContainer(){
		if(this.Container !== undefined){
			this.Container = `{"text": "\n§r"}, {"translate": "juan.entity.container"},{"text": " §9${this.entity.getComponent("minecraft:inventory").container.emptySlotsCount}§r/§9${this.entity.getComponent("minecraft:inventory").container.size}"},`;
		}else {this.Container = `{"text": ""},`; }
	}
	queryNombre(){
		if(this.entity.id !== undefined){
			if(this.entity.id.startsWith("minecraft")){
				this.from = `{"text": "\n§r"},{"translate": "juan.addon.from"},{"text": " §9Minecraft§r"},`;
				this.Nombre = `entity.${this.entity.id.substring(10)}.name`;
			}else{
			this.Nombre = `entity.${this.entity.id}.name`;
			this.from = `{"text": "\n§r"}, {"translate": "juan.addon.from"}, {"text": " §9"}, {"translate": "addon.${this.entity.id.split(":")[0]}.name"},`;
			}
		}else{
           this.Nombre = "";
           this.from = `{"text": ""},`;
         }
	}
	queryVida(){
		if(this.entity.getComponent("minecraft:health") !== undefined){
			this.Vida = `{"text": "\n§r"}, {"translate": "juan.entity.health"}, {"text": " §9${Math.floor(this.entity.getComponent("minecraft:health").current)}§r/§9${Math.floor(this.entity.getComponent("minecraft:health").value)}"},`;
		}else{this.Vida = `{"text": ""},`}
		if(this.entity.getComponent("minecraft:tameable") !== undefined){
			var ITEMS = this.entity.getComponent("minecraft:tameable").tameItems;
			if(ITEMS !== undefined){
			for(var i in ITEMS){
              if(ITEMS[i].startsWith("minecraft")){
              	if(ITEMS.indexOf(ITEMS[i]) >= 1){ITEMS[i] = `{"text": ""}`;}else{
                ITEMS[i] = `{"translate": "item.${ITEMS[i].substring(10)}.name"}`; }
              }else{if(ITEMS.indexOf(ITEMS[i]) >= 1){ITEMS[i] = `{"text": "" }`;}else{ITEMS[i] = `{"translate": "item.${ITEMS[i]}.name"}`;}}
            }}else{ITEMS = `{"text": ""}`};
			this.pet = `{"text": "\n§r"},{"translate": "juan.entity.pet"},{"text": "\n§r"},{"translate": "juan.tame.items"},{"text": "[§9"},${ITEMS},{"text": "§r]"}`;
		}else{ this.pet = `{"text": ""}`; }
	}
	displayIcon(){
		try{
			Minecraft.Commands.run(`titleraw @a[name="${this.target}",tag=${this.tag}] actionbar {"rawtext": [ {"text": "textures/WITE/${this.entity.id.split(":")[1]}" } ] }`, Minecraft.World.getDimension("overworld"));
		}catch(error){}
	}
	showDatos(){
		try{
		Minecraft.Commands.run(`titleraw @a[name="${this.target}",tag=${this.tag}] title { "rawtext": [ {"translate": "juan.entity.type"},{"text": " §9" }, { "translate": "${this.Nombre}" },${this.NameTag + this.Vida +this.color + this.Container + this.animal + this.age + this.from + this.pet}]}`, Minecraft.World.getDimension("overworld"));
	}catch(error){ 
    }
	}
}
