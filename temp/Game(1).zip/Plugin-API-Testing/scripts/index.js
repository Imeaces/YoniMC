import { World, Commands } from 'Minecraft';
import { Game } from './game.js';

let game = null;
let tickCountDown = 20;

World.events.chat.subscribe((event) => {
	if (event.message == 'start') {
		game = new Game(0, 5, 0, 40, 'glass', 0);
		Commands.run('say game started');
	}
});

World.events.tick.subscribe(() => {
	if (tickCountDown-- == 0)
	{
		tickCountDown = 20;
		if (game != null)
		{
			game.handleSecond();
		}
	}
});