import { Commands } from 'Minecraft';

export class Game {
	l; r; t; b; h; o;
	round;
	roundTick;
	selectedId;
	
	fillWall(l, r, t, b, h, o, blockName, blockDamage) {
		this.fillAt(l, h, t, r, o, t, blockName, blockDamage);
		this.fillAt(l, h, b, r, o, b, blockName, blockDamage);
		this.fillAt(l, h, t, l, o, b, blockName, blockDamage);
		this.fillAt(r, h, t, r, o, b, blockName, blockDamage);
		this.fillAt(l + 1, h, t + 1, r - 1, o, b - 1, 'air', 0);
	};
	
	clearWall(l, r, t, b, h, o) {
		this.fillWall(l, r, t, b, h, o, 'air', 0);
	};
	
	fillAt(sX, sY, sZ, eX, eY, eZ, blockName, blockDamage) {
		try {
			Commands.run(`execute @r ~ ~ ~ fill ${sX} ${sY} ${sZ} ${eX} ${eY} ${eZ} ${blockName} ${blockDamage}`);
		}
		catch (e) {
			//ignore = =
		}
	};
	
	placeAt(x, y, z) {
		try {
			Commands.run(`execute @r ~ ~ ~ setblock ${x} ${y} ${z} concrete ${parseInt(Math.random() * 16)}`);
		}
		catch (e) {
		}
	};
	
	placeBlocks() {
		for (let x = this.l; x < this.r; x++) {
			for (let z = this.t; z < this.b; z++) {
				this.placeAt(x, this.o, z);
			}
		}
	};
	
	clearBlocks() {
		for (let i = 0; i < 16; i++)
		{
			if (i == this.selectedId)
				continue;
			try {
				Commands.run(`execute @r ~ ~ ~ fill ${this.l} ${this.o} ${this.t} ${this.r} ${this.o} ${this.b} air 0 replace concrete ${i}`);
			}
			catch (e) {
			}
		}
	};
	
	giveSelected() {
		try {
			Commands.run(`execute @r ~ ~ ~ give @a concrete 1 ${this.selectedId}`);
		}
		catch (e) {
		}
	};
	
	handleSecond() {
		let roundTick = this.roundTick--;
		if (roundTick == 5)	{
			this.clearBlocks();
		} else if (roundTick == 10) {
			this.giveSelected();
		} else if (roundTick == 0) {
			this.newRound();
		} else if (roundTick > 5) {
			Commands.run(`say ${this.roundTick - 5} seconds left...`);
		}
	};
	
	newRound() {
		this.round += 1;
		this.roundTick = 15;
		this.placeBlocks();
		this.selectedId = parseInt(Math.random() * 16);
	};
	
	constructor(startX, startY, startZ, areaSize, wallBlock, wallDamage) {
		let offset = areaSize >> 1;
		this.l = startX - offset;
		this.r = startX + offset;
		this.t = startZ - offset;
		this.b = startZ + offset;
		this.h = startY + 5;
		this.o = startY - 1;
		this.fillWall(this.l - 1, this.r + 1, this.t - 1, this.b + 1, this.h, this.o, wallBlock, wallDamage);
		this.newRound();
	};
}