
import {Commands, World} from 'Minecraft';

World.events.beforeChat.subscribe((event) => {
  try{
  
  const {message} = event;
  
  const a = Commands.run(`scoreboard players test "${event.sender.name}" ${message} * *`).statusMessage.split("在")[0].replaceAll("分数","").replaceAll(" ",""); 


  Commands.run(`titleraw @a title {"rawtext":[{"text": "${message}的分数为${a}"}]}`);
  Commands.run(`me `+a);
  
  } catch (good){
  
  Commands.run(`me 此程序依赖此${good}运行`);
  
  
  }
  
  
  
  
})