
import {Commands, World} from 'Minecraft';

World.events.beforeChat.subscribe((event) => {
  try{
    const {message} = event;
  
  //此处用玩家说的话-message-代替积分项目。以发言玩家event.sender.name代替指定实体
  
  //获取指定玩家的tag列表，去除颜色代码等
  
    var playerTagArr = function (Name){
    var delColor = function(obj){return obj.slice(2,-2);};
    return playerTagArr = Commands.run(`tag "${Name}" list`).statusMessage.split("：")[1].split(",").map(delColor);
    };
  
  Commands.run(`me `+playerTagArr(event.sender.name));
  
  
  
  
  
    //==========================================================================================================//
    //玩家列表
    //==========================================================================================================//
    
    
    
    
     var getPlayerListArr = Commands.run(`list`).statusMessage.split(String.fromCharCode(10))[1].split(",");
    
    
    
    
    
    //==========================================================================================================//
    //指定实体-指定项目的分数 (达成 a 
    //==========================================================================================================//
  var getScorePlayerStr = function (playerName,obj){return Commands.run(`scoreboard players test "${playerName}" ${obj} * *`).statusMessage.split("在")[0].replaceAll("分数","").replaceAll(" ","");};
  
  // 最终结果是一个***类型的数字
  //==========================================================================================================//
  //下面是 - 世界中全部记分项目清单 ( b
  //==========================================================================================================//


  var  getScoreAllArr = function(){
       var b = Commands.run(`scoreboard objectives list`).statusMessage.split(String.fromCharCode(10));
 
          b.shift() //掐头
       var n = function(arr){return arr.slice(2,-1).split("：").shift();};//反复掐头去尾

      return b.map(n);
  
  };
  
  
  //==========================================================================================================//
  //指定玩家的项目清单 ( c
  //==========================================================================================================//

  
  
  var  getScoreListArr = function(Name){//麻辣烫开始
  
           var c = Commands.run(`scoreboard players list "${Name}"`).statusMessage.split(String.fromCharCode(10));
     
              c.shift() //掐头
              
           var malatang = function (arr){return arr.slice(arr.indexOf("(") +1 ,-1);};  //这个是object_Name
    //     var malatang = function (arr){return return arr.slice(2,arr.indexOf(":"));}; //这个实际上是display_Name           

   return c.map(malatang); //进行上面的「麻辣烫」处理
  
  };//麻辣烫结束
  
  
  //演示代码。进存档聊天栏输入记分板项目名 例如 测试

  Commands.run(`titleraw @a title {"rawtext":[{"text": "${message}的分数为${getScorePlayerStr( event.sender.name , message )}"}]}`);
  
  Commands.run(`me `+getScorePlayerStr( event.sender.name , message )+String.fromCharCode(10)+getScoreAllArr()+String.fromCharCode(10)+getScoreListArr(event.sender.name));
  
  
  
  
  
  
  
    //==========================================================================================================//
    //由b衍生而来的功能。使用object名称查询display_Name
  
  
 

  
  var  getScoreNameStr = function(obj){
      var d = Commands.run(`scoreboard objectives list`).statusMessage.split(String.fromCharCode(10));//获取源信息
          d.shift(); //掐头
      var n = function(z){return z.slice(2,z.indexOf("，类型为 ")-1).split("：显示为 '");};
          d = d.map(n);    //进行预处理-去尾-除脏

  for(var i=0;i<=d.length;i++){if (obj == d[i][0]){return d[i][1];};};
  
  return;

  };
  
  
  
    Commands.run(`me `+getScoreNameStr(message));
  
  
    //==========================================================================================================//
    //由b衍生而来的功能。使用display_Name名称查询object
  
  
  
  var  getScoreObjStr = function(Name){
      var d = Commands.run(`scoreboard objectives list`).statusMessage.split(String.fromCharCode(10));//获取源信息
          d.shift(); //掐头
      var n = function(z){return z.slice(2,z.indexOf("，类型为 ")-1).split("：显示为 '");};
          d = d.map(n);    //进行预处理-去尾-除脏

  for(var i=0;i<=d.length;i++){if (Name == d[i][1]){return d[i][0];};};
  
  return;

  };
  
  
  
   // Commands.run(`me `+getScoreObjStr(message));
  
  
  
  
  
  
  } catch (good){
  
  Commands.run(`me ${good}`);
  
  
  }
  
  
  
  
})