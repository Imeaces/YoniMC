// @ts-nocheck
//把mc分成多个部分？
//在这之前，还需要Database
export class RegionManager {
}
export class Region {
}
