// @ts-nocheck
import * as MojangNet from "@minecraft/server-net";
export { MojangNet };
