// @ts-nocheck
export * from "mojang-gametest";
export * as Gametest from "mojang-gametest";
