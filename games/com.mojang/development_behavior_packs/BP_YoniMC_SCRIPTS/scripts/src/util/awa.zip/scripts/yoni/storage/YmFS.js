import { ByteBlock } from "./ByteBlock.js";
import Scoreboard from "../scoreboard.js";
const block = new ByteBlock(Scoreboard.getObjective("yoni:ym_file_system_default_block", true));
export class YmFSAddressManager {
}
