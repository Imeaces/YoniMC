export class KeyValueStorage {
}
