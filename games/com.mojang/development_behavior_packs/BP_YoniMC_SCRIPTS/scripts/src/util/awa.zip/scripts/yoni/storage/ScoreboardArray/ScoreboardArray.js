"use strict";
// @ts-nocheck
/**
 * @interface
 */
class ScoreboardArray {
    /**
     * @type {number}
     */
    length;
}
