// @ts-nocheck
export const API_URL = "your api access url";
export const API_KEY = "your api verify key";
export const QQNumber = 123456; //which bot to use
export const GroupNumbers = [
    8888888888,
]; //which group to use
export const AdminList = [
    110,
    119
];
