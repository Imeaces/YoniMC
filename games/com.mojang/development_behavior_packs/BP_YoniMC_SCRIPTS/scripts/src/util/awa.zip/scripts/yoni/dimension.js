export class Dimension {
    static from(dim) {
        if (false) {
        }
    }
}
