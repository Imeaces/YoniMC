// @ts-nocheck
export const API_URL = "http://127.0.0.1:40233/";
export const API_KEY = '?#3838h（$！3（3（（3@（#（2jbwbeu7wy6iww:q:u;*;!![{`{`{}`}}2）29826-$';
export const QQNumber = 948995706; //which bot to use
export const GroupNumbers = [
    532861538,
    932182724,
]; //which group to use
export const AdminList = [
    3133665839,
    3340629014
];
