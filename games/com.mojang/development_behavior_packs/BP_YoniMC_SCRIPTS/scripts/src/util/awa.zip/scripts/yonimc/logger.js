// @ts-nocheck
import { Logger } from "../yoni/util/Logger.js";
export const logger = new Logger("YoniMC");
export default logger;
