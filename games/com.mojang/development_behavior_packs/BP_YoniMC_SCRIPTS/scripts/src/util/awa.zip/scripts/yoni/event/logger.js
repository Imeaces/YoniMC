import { Logger } from "../util/Logger.js";
export const logger = new Logger("Event");
