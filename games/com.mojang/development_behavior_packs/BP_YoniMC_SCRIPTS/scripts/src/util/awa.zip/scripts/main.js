// @ts-nocheck
import { Logger } from "./yoni/util/Logger.js";
let logger = new Logger("MAIN");
const loadList = [
    "./test.js",
    "./yonimc/main.js"
];
Promise.allSettled(loadList
    .map(path => import(path))
    .map(pro => pro.catch(logger.error)))
    .finally(() => logger.info("scripts MAIN end"));
