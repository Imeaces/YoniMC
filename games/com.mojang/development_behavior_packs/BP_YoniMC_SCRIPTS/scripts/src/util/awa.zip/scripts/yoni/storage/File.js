"use strict";
// @ts-nocheck
class File {
    constructor() {
    }
}
