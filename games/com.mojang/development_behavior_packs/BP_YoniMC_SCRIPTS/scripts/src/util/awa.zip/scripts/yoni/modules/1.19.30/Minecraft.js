// @ts-nocheck
export * from "mojang-minecraft";
export * as Minecraft from "mojang-minecraft";
