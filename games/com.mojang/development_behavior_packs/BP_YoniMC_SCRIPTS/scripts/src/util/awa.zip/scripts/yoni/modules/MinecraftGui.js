// @ts-nocheck
export * from "@minecraft/server-ui";
export * as MinecraftGui from "@minecraft/server-ui";
