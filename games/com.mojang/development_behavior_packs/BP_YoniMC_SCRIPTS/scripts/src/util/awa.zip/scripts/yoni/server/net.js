// @ts-nocheck
export * as ServerNet from "@minecraft/server-net";
export * as default from "@minecraft/server-net";
