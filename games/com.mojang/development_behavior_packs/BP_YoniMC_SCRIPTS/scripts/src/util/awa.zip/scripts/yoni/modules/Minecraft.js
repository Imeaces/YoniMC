// @ts-nocheck
export * from "@minecraft/server";
export * as Minecraft from "@minecraft/server";
