// @ts-nocheck
export const debug = true;
export function isDebug() {
    return debug;
}
