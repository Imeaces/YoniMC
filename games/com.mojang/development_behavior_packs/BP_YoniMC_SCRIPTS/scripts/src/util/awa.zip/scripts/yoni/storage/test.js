// @ts-nocheck
import { coverBase } from "./AddressUtils.js";
console.log(coverBase(100000, 2));
