// @ts-nocheck
export class Memu {
}
