// @ts-nocheck
export * from "mojang-minecraft-ui";
export * as MinecraftGui from "mojang-minecraft-ui";
