// @ts-nocheck
export * from "@minecraft/server-gametest";
export * as Gametest from "@minecraft/server-gametest";
