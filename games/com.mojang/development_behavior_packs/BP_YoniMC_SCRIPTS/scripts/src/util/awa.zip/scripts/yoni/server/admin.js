// @ts-nocheck
export * as ServerAdmin from "@minecraft/server-admin";
export * as default from "@minecraft/server-admin";
