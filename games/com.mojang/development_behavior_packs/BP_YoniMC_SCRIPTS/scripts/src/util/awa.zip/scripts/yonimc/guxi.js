// @ts-nocheck
import { ChatCommand } from "../yoni/util/ChatCommand.js";
import { Minecraft } from "../yoni/basis.js";
import { EntityBase } from "../yoni/entity.js";
import Command from "../yoni/command.js";
import { Scoreboard } from "../yoni/scoreboard.js";
import { Logger } from "../yoni/util/Logger.js";
const { MinecraftEffectTypes, EntityDamageCause, EntityQueryScoreOptions } = Minecraft;
const logger = new Logger("Species.guxi");
class GuxiMain {
    static instance;
    static keyNames = {
        "guxi:energy": "能量堆",
        "guxi:energy_pool": "能量池",
        "guxi:energy_st": "堆上限",
        "guxi:energy_stpo": "池上限",
        "guxi:health_stat": "生命状态",
        "guxi:ef_speed": "速度",
        "guxi:ef_mining": "挖掘",
        "guxi:ef_damage": "伤害",
        "guxi:ef_res": "防御",
        "guxi:ef_fireimmu": "火抗",
        "guxi:auto_energy": "自动获得能量",
        "guxi:keep_res": "保持防御",
        "guxi:keep_ef": "保持状态",
        "guxi:like_player": "伪装玩家",
        "guxi:auto_player": "自行伪装玩家",
        "guxi:hotbar_ctrl": "热键控制",
        "guxi:cre_ely": "伪鞘翅"
    };
    static readAccessKeys() {
        return GuxiMain.keyNames;
    }
    static writeAccessKeys = [
        "guxi:ef_speed",
        "guxi:ef_mining",
        "guxi:ef_damage",
        "guxi:ef_res",
        "guxi:ef_fireimmu",
        "guxi:auto_energy",
        "guxi:keep_res",
        "guxi:keep_ef",
        "guxi:like_player",
        "guxi:auto_player"
    ];
    values = Scoreboard.getObjective("guxi:values", true);
    objectives = new Proxy((function () {
        let objs = {};
        Object.keys(GuxiMain.keyNames).forEach(key => {
            let obj = Scoreboard.getObjective(key, true);
            objs[key] = obj;
        });
        objs.species = Scoreboard.getObjective("species", true);
        return objs;
    })(), {
        get(t, k) {
            if (typeof k === "symbol") {
                return t[k];
            }
            if (k === "species") {
                return t.species;
            }
            if (!k.startsWith("guxi:")) {
                return t["guxi:" + k];
            }
            return t[k];
        }
    });
    constructor() {
        GuxiMain.instance = this;
    }
    onBlockBroken(event) {
        if (!EntityBase.hasFamily(event.player, "guxi"))
            return;
        this.objectives.energy.postRemoveScore(event.player, Math.round(Math.max(0, 72219 * this.objectives["ef_mining"].getScore(event.player))));
    }
    onCommand(sender, command, label, args) {
        if (!sender.hasFamily("guxi")) {
            sender.sendMessage("抱歉，非本族群不可使用");
            return ChatCommand.unknownCommand;
        }
        switch (args.shift()) {
            case "boom":
                this.createBoom(sender, args.shift());
                break;
            case "value":
                this.valueCtrl(sender, args);
                break;
            case "elytra":
                elytraManage(sender, args);
                break;
            default:
                sender.sendMessage("咕西");
                sender.sendMessage(`${label} value [set|get|list]`);
                sender.sendMessage(`${label} boom <radius:number>`);
                sender.sendMessage(`${label} elytra <expand|recovery>`);
        }
    }
    hurtCondition3(event) {
        if (event.damagingEntity == null || !!EntityBase.hasFamily(event.damagingEntity, "guxi")) {
            return;
        }
        let cost = Math.round(event.damage * 722 * (this.objective["guxi:ef_damage"].getScore(event.damagingEntity) + 1));
        if (cost > 0) {
            this.objective["guxi:energy"].removeScore(event.damagingEntity, cost);
        }
    }
    hurtCondition1(event) {
        if (!EntityBase.hasAnyFamily(event.damagingEntity, "guxi"))
            return;
        if (event.hurtEntity.getComponent("minecraft:health").current == 0) {
            let damageEnergyEntity = event.hurtEntity.dimension.spawnEntity("guxi:energy", event.hurtEntity.location);
            let damageEnergy = event.hurtEntity.getComponent("minecraft:health").value ^ 5 * 32;
            let damageEnergies = Math.floor(damageEnergy / 10000000);
            damageEnergy = damageEnergy % 10000000;
            runCmd("scoreboard players set @s guxi:energies " + damageEnergies, damageEnergyEntity);
            runCmd("scoreboard players set @s guxi:energy " + damageEnergy, damageEnergyEntity);
        }
        return;
    }
    lavaUseCondition(event) {
        if (event.item.id === "minecraft:lava_bucket" && event.source != null && EntityBase.hasFamily(event.source, "guxi")) {
            event.cancel = true;
            let ent = event.source;
            Command.fetchExecute(ent, "replaceitem entity @s slot.weapon.mainhand 0 bucket 1");
            let lavaBucketEnergyVolume = Obj.get("values", "lava_bucket_energy_volume");
            Obj.add("energy", ent, Math.round(lavaBucketEnergyVolume
                * Math.max(1, 100 * Math.random())));
            ent.dimension
                .spawnItem(new Minecraft.ItemStack(Minecraft.MinecraftItemTypes.obsidian, 1, 0), ent.location);
        }
    }
    createExplosion(runner, radius) {
        runner = EntityBase.from(runner);
        radius = Number(radius);
        if (!isFinate(radius)) {
            sender.sendMessage("范围得是数字");
            return;
        }
        let location = new Location(runner);
        runner.say("boom!");
        runner.dimension.createExplosion(location.getVanillaLocation(), radius, {
            breaksBlocks: true,
            source: EntityBase.getMinecraftEntity(runner)
        });
    }
    valueCtrl(sender, args) {
        switch (args.shift()) {
            case "list":
                sender.sendMessage("\n当前状态");
                for (let s in valueList) {
                    let o = Scoreboard.getObjective(s, true);
                    let r = o.getScore(sender);
                    let v = (s in setList) ? "" : "§7";
                    sender.sendMessage(`${v}${valueList[s]}(${o.id}): ${r}`);
                }
                ;
                break;
            case "get":
                let valueToGet = args.shift();
                if (!valueToGet.startsWith("guxi:"))
                    valueToGet = "guxi:" + valueToGet;
                if (valueList[valueToGet] === undefined) {
                    sender.sendMessage("没有");
                    return;
                }
                let valueVal = Obj.get(valueToGet, sender);
                sender.sendMessage(`${valueList[valueToGet]}(${valueToGet}): ${valueVal}`);
            case "set":
                let valueToSet = args.shift();
                if (!valueToSet.startsWith("guxi:"))
                    valueToSet = "guxi:" + valueToSet;
                if (setList[valueToSet] === undefined) {
                    sender.sendMessage("做不到");
                    return;
                }
                let valForValue = args.shift();
                if (valForValue === "false") {
                    valForValue = 0;
                }
                else if (valForValue === "true") {
                    valForValue = 1;
                }
                else {
                    valForValue = Number(valForValue);
                }
                try {
                    Obj.set(valueToSet, sender, valForValue);
                    sender.sendMessage("成功");
                }
                catch (e) {
                    sender.sendMessage("失败");
                }
                break;
            default:
                sender.sendMessage("感到疑惑");
        }
    }
    elytraManage(sender, args) {
        switch (args[0]) {
            case "expand":
                Command.fetchExecute(sender, "function yonimc/guxi/creation/elytra/expand");
                sender.sendMessage("展开鞘翅");
                break;
            case "recovery":
                Command.fetchExecute(sender, "function yonimc/guxi/creation/elytra/recovery");
                sender.sendMessage("收起鞘翅");
                break;
            default:
                sender.sendMessage("感到疑惑");
        }
    }
    hurtCondition2(event) {
        if (!EntityBase.hasFamily(event.hurtEntity, "guxi"))
            return;
        let ent = event.hurtEntity;
        let damage = event.damage;
        let type = "unknown";
        switch (event.cause) {
            case EntityDamageCause.fire:
            case EntityDamageCause.fireTick:
            case EntityDamageCause.freezing:
            case EntityDamageCause.lava:
            case EntityDamageCause.magma:
                type = "hot";
                break;
            case EntityDamageCause.magic:
                type = "magic";
                break;
            case EntityDamageCause.projectile:
            case EntityDamageCause.flyIntoWall:
            case EntityDamageCause.fall:
            case EntityDamageCause.fallingBlock:
            case EntityDamageCause.entityExplosion:
            case EntityDamageCause.blockExplosion:
            case EntityDamageCause.anvil:
                type = "fatal";
                break;
            default:
                type = "normal";
        }
        let maxHealth = EntityBase.getMaxHealth(ent);
        let currentHealth = EntityBase.getCurrentHealth(ent);
        let lostHealth = maxHealth - currentHealth;
        if (type == "fatal") {
            let i = Math.round(Math.max(0, damage
                ** 2
                * 0.01
                * Obj.get("energy_pool", ent)));
            Obj.remove("energy_pool", ent, i);
        }
        else if (type == "hot") {
            ent.addEffect(Minecraft.MinecraftEffectTypes["instantHealth"], 2, 20, false);
            Obj.add("energy_pool", ent, Math.round(damage * Math.max(1, 100 * Math.random())));
            Obj.add("ef_fireimmu", ent, Math.round(Math.max(4, Obj.get("ef_fireimmu", ent) * 3.1 * Math.random())));
            if (Math.random() * 1000 <= 1) {
                Obj.add("energy_pool", ent, Math.round(damage * 500));
                Command.postExecute(ent, [
                    "fill ~-4 ~-4 ~-4 ~4 ~4 ~4 obsidian 0 replace lava 0",
                    "fill ~-4 ~-4 ~-4 ~4 ~4 ~4 netherrack 0 replace magma -1",
                    "fill ~-4 ~-4 ~-4 ~4 ~4 ~4 obsidian 0 replace flowing_lava 0",
                    "fill ~-4 ~-4 ~-4 ~4 ~4 ~4 air 0 replace lava -1",
                    "fill ~-4 ~-4 ~-4 ~4 ~4 ~4 air 0 replace flowing_lava -1",
                    "fill ~-4 ~-4 ~-4 ~4 ~4 ~4 air 0 replace fire -1"
                ]);
            }
        }
        else if (type == "immune") {
            //do nothing
        }
        else {
            let resLevel = Obj.get("ef_res", ent);
            let lost = Math.max(0, Math.min(lostHealth, damage));
            if (resLevel > 0) { //防伤害
                Obj.remove("energy_pool", ent, Math.max(0, Math.round(Math.max(1, damage) / resLevel * 1000)));
                lost = lost - 16;
            }
            if (lost > 0) {
                Obj.remove("energy_pool", ent, Math.round(Math.max(0, lost / maxHealth * Obj.get("energy_pool", ent))));
            }
            //Command.fetchExecute(ent, `title @s title 损失血量 ${lostHealth}`);
            //Command.fetchExecute(ent, `title @s subtitle ${event.cause} ${event.damage}`);
        }
    }
    itemUseCondition(event) {
        if (event.source === undefined || !EntityBase.hasFamily(event.source, "guxi"))
            return;
        if (event.item.id === "yonimc:energy") {
            event.cancel = true;
            let ent = event.source;
            ent.addEffect(Minecraft.MinecraftEffectTypes["instantHealth"], 1, 20, false);
            Obj.add("energy", ent, 30000000);
        }
        else if (event.item.id === "minecraft:firework_rocket" &&
            Obj.get("cre_ely", event.source) === 2 &&
            event.source.selectedSlot === 8) {
            Obj.remove("energy", event.source, 262144);
        }
    }
}
