// @ts-nocheck
import { Minecraft } from "./yoni/basis.js";
Minecraft.system.run(() => {
    Minecraft.world.say("ok");
});
