import { World, Commands} from "Minecraft";
import { getIntTag } from './storage.js';


World.events.beforeChat.subscribe((event) => {
	var score = getIntTag(event.sender.name, 'lvl');
	if (score == null)
		return;
	var message = JSON.stringify({"rawtext":[{"text":`lvl${score} ${event.sender.name} => ${event.message}`}]});
	Commands.run(`tellraw @a ${message}`);
	event.cancel = true;
});
