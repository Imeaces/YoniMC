import { World, Commands} from "Minecraft";
import { getStrTag, putStrTag, removeStrTag } from './storage.js';

const ntAdd = new RegExp('nt add (.+) (.+) (.+)');
const ntRem = new RegExp('nt rem (.+) (.+)');
const ntUse = new RegExp('nt use (.+)');
const ntClear = new RegExp('nt clear');
const operator = 'Steve';

function tellraw(message, target) {
	message = JSON.stringify({"rawtext":[{"text":message}]});
	Commands.run(`tellraw ${target} ${message}`);
}

World.events.beforeChat.subscribe((event) => {
	var matched = event.message.match(ntAdd);
	if (matched != null) {
		if (event.sender.name != operator) {
			tellraw('you have no permission to use this command', `"${event.sender.name}"`);
		} else {
			putStrTag(matched[1], matched[2], matched[3]);
			tellraw('ok', `"${event.sender.name}"`);
		}
	} else if ((matched = event.message.match(ntRem)) != null) {
		if (event.sender.name != operator) {
			tellraw('you have no permission to use this command', `"${event.sender.name}"`);
		} else {
			removeStrTag(matched[1], matched[2]);
			tellraw('ok', `"${event.sender.name}"`);
		}
	} else if ((matched = event.message.match(ntClear)) != null) {
		removeStrTag(event.sender.name, 'curnt');
		tellraw('ok', `"${event.sender.name}"`);
	} else if ((matched = event.message.match(ntUse)) != null) {
		var nt = getStrTag(event.sender.name, matched[1]);
		if (nt == null) {
			tellraw('你没有这个称号', `"${event.sender.name}"`);
		} else {
			putStrTag(event.sender.name, 'curnt', nt);
			tellraw('ok', `"${event.sender.name}"`);
		}
	} else {
		var nt = getStrTag(event.sender.name, 'curnt');
		if (nt == null) {
			nt = '无称号的穷逼';
		}
		tellraw(`${nt} ${event.sender.name} => ${event.message}`, '@a');
	}
	event.cancel = true;
});
