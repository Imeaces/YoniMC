import { World, Commands} from "Minecraft";
import { getScore } from './scoreboard.js';

World.events.beforeChat.subscribe((event) => {
	var score = getScore(event.sender.name, 'test');
	if (score == null) {
		score = '无等级';
	}
	var message = JSON.stringify({"rawtext":[{"text":`lvl${score} ${event.sender.name} => ${event.message}`}]});
	Commands.run(`tellraw @a ${message}`);
	event.cancel = true;
});
