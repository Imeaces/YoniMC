import { World, Commands } from 'Minecraft';


export function getScore(playerName, scoreName) {
	let result = Commands.run(`scoreboard players list "${playerName}"`).statusMessage.match(new RegExp(`${scoreName}[\\:|\\：]\\s+([0-9]+)`));
	if (result == null) {
		return null;
	}
	return parseInt(result[1]);
}